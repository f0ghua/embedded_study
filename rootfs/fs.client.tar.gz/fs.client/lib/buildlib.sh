#!/bin/bash

for c_lib_file in $(ls *so*);do
    if [ -f ${c_lib_file} ] && [ ! -h ${c_lib_file} ];then
        #echo $i;
        c_lib_pre=${c_lib_file%%-*};

        echo "replacing ${c_lib_pre}[-.]* ...";

        n_lib_files=$(find /lib/ -maxdepth 1 -name "${c_lib_pre}[-.]*");
        if [ -z "${n_lib_files}" ];then
            echo "Library ${c_lib_pre}-* not found in your system!";
        else
            # remove current library files
            rm -f ${c_lib_pre}[-.]*;
        fi

        for n_lib_file in ${n_lib_files};do            
            cp -a ${n_lib_file} ./;
        done


    fi
done
